using System;
using System.Collections.Generic;

namespace ASPDotNetLearningApplication
{
    public class Role
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
