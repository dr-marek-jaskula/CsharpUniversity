using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;

namespace ASPDotNetLearningApplication
{
    public enum SortDirection
    {
        Ascending, Descending
    }
}
